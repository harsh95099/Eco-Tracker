"""
tracker.py
Core business logic: ActivityLog data class and BudgetTracker.
No Streamlit imports allowed in this module.
"""

import datetime
from typing import Dict, List, Optional, Tuple

from calculator import EmissionCalculator, CATEGORIES
from data_store import DataStore
from tips import TipsEngine


class ActivityLog:
    """Represents a single logged sustainability activity."""

    def __init__(
        self,
        date: datetime.date,
        category: str,
        activity_type: str,
        value: float,
        emission: float,
        description: str = "",
    ) -> None:
        self.date: datetime.date = date
        self.category: str = category
        self.activity_type: str = activity_type
        self.value: float = value
        self.emission: float = emission
        self.description: str = description

    def to_dict(self) -> dict:
        """Serialise to a plain dict suitable for JSON storage."""
        return {
            "date": self.date.isoformat(),
            "category": self.category,
            "activity_type": self.activity_type,
            "value": self.value,
            "emission": self.emission,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ActivityLog":
        """Deserialise from a plain dict (as loaded from JSON)."""
        return cls(
            date=datetime.date.fromisoformat(data["date"]),
            category=data["category"],
            activity_type=data["activity_type"],
            value=float(data["value"]),
            emission=float(data["emission"]),
            description=data.get("description", ""),
        )

    def __repr__(self) -> str:
        return (
            f"ActivityLog(date={self.date}, category={self.category!r}, "
            f"activity_type={self.activity_type!r}, value={self.value}, "
            f"emission={self.emission})"
        )


class BudgetTracker:
    """
    Manages the monthly budget and all activity logs.
    Delegates calculation to EmissionCalculator, persistence to DataStore,
    and tips to TipsEngine.
    """

    def __init__(self) -> None:
        self._calculator: EmissionCalculator = EmissionCalculator()
        self._data_store: DataStore = DataStore()
        self._tips_engine: TipsEngine = TipsEngine()
        self.monthly_budget: float = 0.0
        self.logs: List[ActivityLog] = []
        self._load()

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load saved state from the data store on startup."""
        raw_logs, budget = self._data_store.load()
        self.monthly_budget = budget
        self.logs = []
        for entry in raw_logs:
            try:
                self.logs.append(ActivityLog.from_dict(entry))
            except (KeyError, ValueError):
                # Skip malformed entries silently
                pass

    def _save(self) -> None:
        """Persist current state to the data store."""
        self._data_store.save(
            logs=[log.to_dict() for log in self.logs],
            budget=self.monthly_budget,
        )

    # ------------------------------------------------------------------
    # Budget management
    # ------------------------------------------------------------------

    def set_budget(self, amount: float) -> None:
        """
        Set the monthly carbon budget.

        Args:
            amount: Budget in kg CO2e. Must be > 0.

        Raises:
            TypeError: If amount is not numeric.
            ValueError: If amount is not positive.
        """
        if not isinstance(amount, (int, float)):
            raise TypeError("Budget must be a numeric value.")
        if amount <= 0:
            raise ValueError("Budget must be a positive number greater than zero.")
        self.monthly_budget = float(amount)
        self._save()

    # ------------------------------------------------------------------
    # Activity logging
    # ------------------------------------------------------------------

    def add_log(
        self,
        date: datetime.date,
        category: str,
        activity_type: str,
        value: float,
        description: str = "",
    ) -> ActivityLog:
        """
        Validate inputs, compute emission, append log, and persist.

        Args:
            date: Date of the activity. Must not be in the future.
            category: Must be one of the four allowed categories.
            activity_type: Must belong to the selected category.
            value: Positive numeric quantity.
            description: Optional free-text note.

        Returns:
            The newly created ActivityLog.

        Raises:
            TypeError: If value is not numeric.
            ValueError: For invalid date, category, activity_type, or value.
        """
        if not isinstance(value, (int, float)):
            raise TypeError("Activity value must be a numeric number.")
        if value <= 0:
            raise ValueError("Activity value must be a positive number greater than zero.")
        if not isinstance(date, datetime.date):
            raise TypeError("Date must be a datetime.date instance.")
        if date > datetime.date.today():
            raise ValueError("Activity date cannot be in the future.")
        if category not in CATEGORIES:
            raise ValueError(
                f"Invalid category '{category}'. "
                f"Choose from: {', '.join(CATEGORIES)}."
            )
        # Raises ValueError if activity_type is unknown (delegated to calculator)
        emission = self._calculator.calculate(category, activity_type, value)

        log = ActivityLog(
            date=date,
            category=category,
            activity_type=activity_type,
            value=value,
            emission=emission,
            description=description,
        )
        self.logs.append(log)
        self._save()
        return log

    # ------------------------------------------------------------------
    # Query / reporting
    # ------------------------------------------------------------------

    def _logs_for_month(self, month: int, year: int) -> List[ActivityLog]:
        """Return logs that fall within the given month and year."""
        return [
            log for log in self.logs
            if log.date.month == month and log.date.year == year
        ]

    def get_total_emissions(self, month: int, year: int) -> float:
        """Sum all emissions for the given month and year."""
        return round(sum(log.emission for log in self._logs_for_month(month, year)), 4)

    def get_remaining_budget(self, month: int, year: int) -> float:
        """
        Return remaining budget for the month.
        Can be negative (over-budget).
        Returns 0.0 if no budget has been set.
        """
        return round(self.monthly_budget - self.get_total_emissions(month, year), 4)

    def get_category_breakdown(self, month: int, year: int) -> Dict[str, float]:
        """
        Return per-category total emissions for the given month.

        Returns:
            Dict mapping category name to total kg CO2e.
            All four categories are always present (defaulting to 0.0).
        """
        breakdown: Dict[str, float] = {cat: 0.0 for cat in CATEGORIES}
        for log in self._logs_for_month(month, year):
            breakdown[log.category] = round(breakdown[log.category] + log.emission, 4)
        return breakdown

    def get_top_category(self, month: int, year: int) -> Optional[str]:
        """
        Return the category with the highest total emission for the month.
        Returns None if no activities have been logged.
        """
        breakdown = self.get_category_breakdown(month, year)
        if all(v == 0.0 for v in breakdown.values()):
            return None
        return max(breakdown, key=lambda cat: breakdown[cat])

    def get_tip(self, month: int, year: int) -> str:
        """Return a reduction tip based on the top-emitting category this month."""
        top = self.get_top_category(month, year)
        return self._tips_engine.get_tip(top)

    def get_activity_types(self, category: str) -> List[str]:
        """Delegate to EmissionCalculator for the UI to populate dropdowns."""
        return self._calculator.get_activity_types(category)

    def get_unit(self, category: str, activity_type: str) -> str:
        """Delegate to EmissionCalculator for the UI to show unit labels."""
        return self._calculator.get_unit(category, activity_type)
