# EcoAssistant — Phased Execution Roadmap

## Overview

Build and deploy EcoAssistant: a multi-agent AI sustainability platform powered by IBM Bob. The
system routes user queries through an **Orchestrator Agent** that classifies intent and delegates
to one of four specialized sub-agents (EduAgent, TrackerAgent, RecycleAgent, CommunityAgent) via
a FastAPI orchestration layer. The backend is Python/FastAPI with PostgreSQL, Redis, and ChromaDB.
The frontend is a React dashboard. All agents operate under a shared EcoAssistant IBM Bob custom
mode with guardrails enforcing scientific integrity and zero greenwashing.

**Scope:** Greenfield build — workspace is empty, all infrastructure is created from scratch.

**Non-goals:**
- No native mobile app (web-only for this plan)
- No paid third-party climate APIs unless freely available alternatives are exhausted
- No multi-tenancy or enterprise auth in this iteration

---

## Agent Specifications

### Orchestrator Agent (Router & Supervisor)

**Role:** Acts as the primary entry point, analyzing user intent and delegating execution to
specialized sub-agents. Returns structured JSON routing decisions and combines multi-agent
responses seamlessly.

**System Prompt:**
```
You are the Orchestrator for EcoAssistant. Evaluate incoming user inputs and classify intent
into one of four sub-agent categories: EduAgent (climate facts/science), TrackerAgent
(footprint calculations/habits), RecycleAgent (waste sorting/disposal), or CommunityAgent
(events/leaderboards). Return structured JSON routing decisions and combine multi-agent
responses seamlessly.
```

**Output:** Structured JSON routing decision → `{ "intent": "edu|tracker|recycle|community", "agent": "<AgentName>", "payload": { ... } }`

---

### EduAgent (Climate Knowledge & Science)

**Role:** Solves educational queries, counters greenwashing, and provides cited climate facts.

**System Prompt:**
```
You are EduAgent. Answer scientific questions regarding climate change, policy, and
environmental science using retrieved context from verified sources (IPCC, EPA, NASA).
Always cite sources directly and translate complex data into clear, accessible language.
```

**Tool Schema:**
```python
search_climate_db(query: str, domain: str) -> list[DocumentChunk]
# Returns top verified document chunks from ChromaDB climate_knowledge collection
# domain: "ipcc" | "epa" | "nasa" | "all"
```

**Input Type:** Text queries
**Primary Data Source:** Vector DB (ChromaDB — IPCC, NASA, EPA ingested documents)
**Output Format:** Cited text response `{ "answer": str, "citations": list[Citation], "action_step": str }`

---

### TrackerAgent (Footprint & Personal Impact)

**Role:** Collects habit metrics, calculates CO2e emissions, and generates personalized
reduction goals.

**System Prompt:**
```
You are TrackerAgent. Collect quantitative lifestyle inputs (electricity kWh, transport
miles/km, dietary habits) and calculate net CO2e emissions using standardized emission
factors. Return actionable, prioritized reduction steps.
```

**Tool Schema:**
```python
calculate_footprint(category: str, value: float, unit: str) -> FootprintResult
# category: "electricity" | "transport" | "diet" | "waste" | "flight"
# Returns: { "co2e_kg": float, "reduction_strategies": list[str] }
```

**Input Type:** Numeric habits / activity logs
**Primary Data Source:** EPA Emission Factor datasets (constants embedded in `formulas.py`)
**Output Format:** Interactive progress JSON `{ "total_co2e_kg": float, "breakdown_by_domain": dict, "reduction_steps": list[str] }`

---

### RecycleAgent (Waste Segregation & Sorting)

**Role:** Categorizes items and provides step-by-step local disposal guidelines.

**System Prompt:**
```
You are RecycleAgent. Process item text descriptions or visual attributes to classify
waste into strict streams: Compost, Recyclable, E-Waste, or Hazardous. Provide immediate,
step-by-step instructions for proper cleaning and local disposal.
```

**Tool Schema:**
```python
classify_waste_item(item_description: str, local_zipcode: str) -> WasteClassification
# Returns: { "category": "compost|recyclable|e-waste|hazardous",
#             "recyclability_status": str,
#             "handling_steps": list[str],
#             "confidence": float }
```

**Input Type:** Image upload and/or item text description + zipcode
**Primary Data Source:** Waste Classification DB (PostgreSQL `RecyclingRule` table) + CLIP vision model
**Output Format:** Step-by-step handling guide with category, recyclability status, and local instructions

---

### CommunityAgent (Local Action & Gamification)

**Role:** Connects users with local initiatives, tracks volunteer impact, and manages
community leaderboards.

**System Prompt:**
```
You are CommunityAgent. Match user geolocation with local environmental events, cleanups,
and sustainability challenges. Track user participation, award impact badges, and update
community progress.
```

**Tool Schema:**
```python
get_local_events(location: str, radius_km: int) -> list[LocalEvent]
# Returns list of nearby sustainability events and registration links
# location: city name, address, or "lat,lon" string
```

**Input Type:** Geolocation / User ID
**Primary Data Source:** Event Registry (PostgreSQL) & Leaderboard DB (Redis sorted sets)
**Output Format:** Local event cards + points `{ "events": list[Event], "user_points": int, "leaderboard_rank": int }`

---

## Sub-Agent Execution Flow Matrix

| Sub-Agent | Input Type | Primary Data Source | Output Format |
|---|---|---|---|
| EduAgent | Text queries | Vector DB (IPCC, NASA, EPA) | Cited text response |
| TrackerAgent | Numeric habits / logs | EPA Emission Factor datasets | Interactive progress JSON & tips |
| RecycleAgent | Image / item description | Waste Classification DB | Step-by-step handling guide |
| CommunityAgent | Geolocation / User ID | Event Registry & Leaderboard DB | Local event cards & points |

---

## Phase 1 — Environment & Architecture Setup

### Sub-Task 1.1 — Project Scaffold & Python Environment

**Intent:**
Establish the foundational repository layout and Python package configuration so every subsequent
sub-task has a consistent place to land its code.

**Expected Outcomes:**
- A directory tree matching the agreed project layout exists in the workspace root.
- `pyproject.toml` (or `requirements.txt`) lists all top-level runtime and dev dependencies.
- A `.gitignore` appropriate for Python + Node is present.
- Running `pip install -e .` (or equivalent) completes without errors.

**Todo List:**
- [ ] Create top-level directories: `backend/`, `frontend/`, `agents/`, `infra/`, `data/`, `.bob/`
- [ ] Create `backend/main.py` as the FastAPI entry point (empty router, health check endpoint)
- [ ] Create `backend/requirements.txt` listing: `fastapi`, `uvicorn`, `pydantic`, `sqlalchemy`,
  `psycopg2-binary`, `redis`, `chromadb`, `sentence-transformers`, `pillow`, `httpx`
- [ ] Create `frontend/` placeholder with `package.json` scaffold (React + Vite)
- [ ] Add `.gitignore` (Python venv, `__pycache__`, `.env`, `node_modules`)
- [ ] Add `README.md` with project description and local-run instructions

**Relevant Context:**
- Workspace root: `c:\Users\DELL\OneDrive\Desktop\P1`
- No existing files; create everything from scratch.

**Status:** [ ] pending

---

### Sub-Task 1.2 — Database & Cache Configuration

**Intent:**
Define and provision the PostgreSQL schema for persistent data (users, footprint histories,
community events) and configure Redis for leaderboard caching. Use Docker Compose so the full
stack spins up with a single command.

**Expected Outcomes:**
- `infra/docker-compose.yml` starts PostgreSQL and Redis services locally.
- `backend/db/models.py` declares SQLAlchemy ORM models for: `User`, `FootprintEntry`,
  `CommunityEvent`, `UserEventCheckIn`, `RecyclingRule`.
- `backend/db/init.sql` contains the raw DDL for manual inspection and CI migrations.
- Running `docker compose up -d` brings up both services with no errors.

**Todo List:**
- [ ] Create `infra/docker-compose.yml` with `postgres:15` and `redis:7-alpine` services,
  named volumes, and exposed ports (5432, 6379)
- [ ] Create `backend/db/models.py` with SQLAlchemy ORM models (User, FootprintEntry,
  CommunityEvent, UserEventCheckIn, RecyclingRule)
- [ ] Create `backend/db/session.py` with SQLAlchemy engine and `get_db` dependency
- [ ] Create `backend/db/init.sql` mirroring the ORM models as raw DDL
- [ ] Add `.env.example` with `DATABASE_URL`, `REDIS_URL`, `SECRET_KEY` placeholders
- [ ] Verify `alembic` or manual migration script can apply the schema to a running container

**Relevant Context:**
- PostgreSQL holds user profiles, footprint histories, events, check-ins, recycling rules.
- Redis holds leaderboard scores (sorted sets) and caches frequent query results.
- ORM models defined here are consumed by TrackerAgent (1.3), CommunityAgent (2.4), and
  RecycleAgent (2.3).

**Status:** [ ] pending

---

### Sub-Task 1.3 — IBM Bob EcoAssistant Custom Mode

**Intent:**
Register the EcoAssistant persona, guardrails, and intent routing rules as an IBM Bob custom mode
so the assistant behaves correctly inside the IDE during development and evaluation.

**Expected Outcomes:**
- `.bob/custom_modes.yaml` exists with a valid `eco-assistant` mode entry.
- The mode appears in the IBM Bob mode picker immediately (hot-reload).
- The mode is workspace-scoped (not global).

**Todo List:**
- [ ] Create `.bob/custom_modes.yaml` with the `eco-assistant` slug
- [ ] Set `roleDefinition` to the full EcoAssistant persona and principles
  (scientific integrity, zero greenwashing, positive framing, actionable guidance)
- [ ] Set `customInstructions` with the four intent routing rules
  (EduAgent, TrackerAgent, RecycleAgent, CommunityAgent)
- [ ] Set `groups` to `[read]` only (no edit or execute permissions)
- [ ] Confirm the slug passes the `^[a-zA-Z0-9-]+$` regex and is unique in the file

**Relevant Context:**
- Slug: `eco-assistant`
- Scope: workspace (`.bob/custom_modes.yaml`, not `~/.bob/settings/custom_modes.yaml`)
- Tool groups reference: `read` enables file reading and search; no `edit` or `execute`

**Status:** [ ] pending

---

## Phase 2 — Sub-Agent & Core Engine Development

### Sub-Task 2.1 — EduAgent: RAG Pipeline

**Intent:**
Build the education sub-agent that answers climate facts, policy, and science questions by
retrieving relevant passages from ingested IPCC, EPA, and NASA reports stored in ChromaDB, then
generating a cited answer.

**Expected Outcomes:**
- `agents/edu_agent/ingest.py` ingests source documents into ChromaDB collections.
- `agents/edu_agent/retriever.py` performs semantic search and returns top-k passages with metadata
  (source, page, date).
- `agents/edu_agent/agent.py` composes retrieved passages into a cited, actionable answer.
- A FastAPI endpoint `POST /agents/edu` accepts a question and returns a structured JSON response
  with `answer`, `citations`, and `action_step`.

**Todo List:**
- [ ] Create `agents/edu_agent/` directory with `__init__.py`
- [ ] Create `agents/edu_agent/ingest.py`: load PDF/text climate reports from `data/sources/`,
  chunk with overlap, embed using `sentence-transformers`, persist to ChromaDB collection
  `climate_knowledge`
- [ ] Create `agents/edu_agent/retriever.py`: query ChromaDB collection, return top-5 passages
  with source citations
- [ ] Create `agents/edu_agent/agent.py`: compose LLM prompt from retrieved context, enforce
  citation requirement, append one action step
- [ ] Add `POST /agents/edu` route to `backend/main.py`
- [ ] Add sample source documents to `data/sources/` (IPCC AR6 summary, EPA climate page excerpts)
- [ ] Write unit tests in `agents/edu_agent/tests/` covering retrieval and response structure

**Relevant Context:**
- Vector DB: ChromaDB (local-first, no server needed in dev)
- Embedding model: `sentence-transformers/all-MiniLM-L6-v2` (lightweight, local)
- Guardrail: every response must include at least one citation; agent must refuse to answer if
  no relevant context is retrieved (acknowledge limits, do not speculate)

**Status:** [ ] pending

---

### Sub-Task 2.2 — TrackerAgent: Carbon Calculator

**Intent:**
Build the carbon footprint tracking sub-agent that accepts user-submitted activity data (energy
use, transport, diet, waste), calculates CO2e emissions using established formulas, persists
entries to PostgreSQL, and returns a breakdown with personalized reduction steps.

**Expected Outcomes:**
- `agents/tracker_agent/formulas.py` encapsulates emission factor constants and calculation
  functions for energy, transport, diet, and waste domains.
- `agents/tracker_agent/agent.py` accepts structured input, calls formulas, persists a
  `FootprintEntry` record, and returns a JSON breakdown.
- A FastAPI endpoint `POST /agents/tracker` accepts activity data and returns CO2e totals and
  reduction recommendations.
- Emission factors are sourced from EPA Emission Factors Hub (referenced inline).

**Todo List:**
- [ ] Create `agents/tracker_agent/` directory with `__init__.py`
- [ ] Create `agents/tracker_agent/formulas.py` with EPA-sourced emission factors and
  calculation functions for: electricity (kWh), natural gas (therms), car travel (miles, MPG),
  flights (miles, cabin class), diet type (vegan/vegetarian/omnivore/heavy meat), waste (kg)
- [ ] Create `agents/tracker_agent/schemas.py` with Pydantic input/output models
- [ ] Create `agents/tracker_agent/agent.py` orchestrating calculation, DB persistence, and
  reduction tip generation
- [ ] Add `POST /agents/tracker` route to `backend/main.py`
- [ ] Write unit tests covering each formula function with known expected outputs

**Relevant Context:**
- `FootprintEntry` ORM model defined in Sub-Task 1.2 (`backend/db/models.py`)
- Output JSON schema must include: `total_co2e_kg`, `breakdown_by_domain`, `reduction_steps[]`
- Reduction steps must be concrete and ranked by impact magnitude

**Status:** [ ] pending

---

### Sub-Task 2.3 — RecycleAgent: Vision + Text Sorting Engine

**Intent:**
Build the recycling guidance sub-agent that accepts a photo upload (and optional text description),
classifies the waste item using a vision/text model, maps the result to municipal recycling and
hazardous waste handling rules stored in PostgreSQL, and returns disposal instructions.

**Expected Outcomes:**
- `agents/recycle_agent/classifier.py` accepts an image (base64 or file upload) and optional
  text, returns a waste category label and confidence score.
- `agents/recycle_agent/rule_mapper.py` looks up the identified material in the `RecyclingRule`
  table and returns handling instructions.
- A FastAPI endpoint `POST /agents/recycle` accepts multipart form data (image + optional text)
  and returns structured disposal instructions.

**Todo List:**
- [ ] Create `agents/recycle_agent/` directory with `__init__.py`
- [ ] Create `agents/recycle_agent/classifier.py` integrating a vision model
  (e.g., `transformers` CLIP or EfficientNet fine-tuned on waste categories) for image
  classification; fall back to text-only classification if no image provided
- [ ] Create `agents/recycle_agent/rule_mapper.py` querying `RecyclingRule` table by material
  category; include fallback instructions for unknown items
- [ ] Seed `RecyclingRule` table with initial data covering common categories: plastic (types
  1-7), glass, paper, cardboard, e-waste, hazardous (batteries, paint, chemicals), compostable
- [ ] Create `agents/recycle_agent/schemas.py` with Pydantic models for request/response
- [ ] Add `POST /agents/recycle` route to `backend/main.py` (multipart file upload)
- [ ] Write unit tests with mock images and text inputs covering at least 5 waste categories

**Relevant Context:**
- `RecyclingRule` ORM model defined in Sub-Task 1.2
- Vision model choice: start with CLIP (`openai/clip-vit-base-patch32`) via HuggingFace
  Transformers; zero-shot classification against predefined waste category labels
- Guardrail: if confidence < threshold (e.g. 0.6), surface uncertainty and ask user to provide
  text description instead of guessing

**Status:** [ ] pending

---

### Sub-Task 2.4 — CommunityAgent: Action Hub

**Intent:**
Build the community engagement sub-agent that manages local environmental events, user check-ins,
cumulative impact scores, and leaderboard rankings. Redis sorted sets back the leaderboard for
fast retrieval; PostgreSQL holds the durable records.

**Expected Outcomes:**
- CRUD endpoints exist for community events: `POST /agents/community/events`,
  `GET /agents/community/events`.
- A check-in endpoint `POST /agents/community/checkin` records participation and updates the
  Redis leaderboard atomically.
- `GET /agents/community/leaderboard` returns the top-N users with their cumulative impact
  scores, served from Redis cache.
- `agents/community_agent/agent.py` wraps the above logic with encouraging response text.

**Todo List:**
- [ ] Create `agents/community_agent/` directory with `__init__.py`
- [ ] Create `agents/community_agent/event_service.py` with create/list/get logic for
  `CommunityEvent` and `UserEventCheckIn` ORM models
- [ ] Create `agents/community_agent/leaderboard.py` using Redis `ZADD`/`ZREVRANGE` for
  sorted-set leaderboard operations; include cache invalidation on check-in
- [ ] Create `agents/community_agent/agent.py` composing human-readable encouraging responses
  from event/leaderboard data
- [ ] Add community routes to `backend/main.py`
- [ ] Write unit tests for leaderboard logic using a mock Redis client

**Relevant Context:**
- ORM models (`CommunityEvent`, `UserEventCheckIn`) defined in Sub-Task 1.2
- Redis key pattern: `leaderboard:global` (sorted set, score = cumulative impact points)
- Impact points formula: TBD by product — placeholder of 10 points per check-in for now

**Status:** [ ] pending

---

## Phase 3 — Integration, Testing & Deployment

### Sub-Task 3.1 — Orchestrator Agent & FastAPI Integration Layer

**Intent:**
Implement the Orchestrator Agent as a first-class component with its own system prompt and
structured JSON output. Wire all five agents (Orchestrator + 4 sub-agents) into a unified
FastAPI layer. A single `POST /chat` endpoint accepts a user message, the Orchestrator
classifies intent and emits a routing decision, then the correct sub-agent executes and returns
a unified response envelope. This is the public surface the React frontend calls.

**Expected Outcomes:**
- `agents/orchestrator/agent.py` implements the Orchestrator system prompt and produces a
  structured JSON routing decision: `{ "intent": "edu|tracker|recycle|community", "agent": str, "payload": dict }`.
- `backend/router/orchestrator.py` consumes the routing decision and dispatches to the
  correct sub-agent module.
- `POST /chat` delegates through the Orchestrator and returns a response matching the shared
  `ChatResponse` schema.
- All four sub-agents are reachable through the single chat endpoint.
- Response time target: under 2 seconds for text-only queries (RAG retrieval included).

**Todo List:**
- [ ] Create `agents/orchestrator/` directory with `__init__.py`
- [ ] Create `agents/orchestrator/agent.py` implementing the Orchestrator system prompt and
  JSON routing output schema
- [ ] Create `agents/orchestrator/schemas.py` with Pydantic models for `RoutingDecision`
  and `ChatResponse`: `{ "intent", "agent", "response_text", "data", "citations" }`
- [ ] Create `backend/router/orchestrator.py` consuming `RoutingDecision` and dispatching
  to `edu_agent | tracker_agent | recycle_agent | community_agent` modules
- [ ] Add `POST /chat` route to `backend/main.py` using the orchestrator dispatcher
- [ ] Add request/response logging middleware for latency monitoring
- [ ] Write integration tests covering one happy-path message per agent intent

**Relevant Context:**
- Orchestrator system prompt defined in Agent Specifications section above
- Routing output JSON: `{ "intent": "edu|tracker|recycle|community", "agent": "<AgentName>", "payload": { ... } }`
- For tracker and recycle intents, the Orchestrator should request clarifying fields
  (e.g., zipcode for recycle, activity category for tracker) if missing from the payload
- Intent routing rules mirror the IBM Bob custom mode's `customInstructions` (Sub-Task 1.3)

**Status:** [ ] pending

---

### Sub-Task 3.2 — Guardrail Evaluation Suite

**Intent:**
Build an automated evaluation harness that tests EcoAssistant responses against the four
guardrails: no greenwashing, source accuracy, positive framing, and response latency under 2
seconds. This runs as a CI step before any deployment.

**Expected Outcomes:**
- `tests/eval/guardrail_suite.py` contains a test suite with labeled prompt/expected-behavior
  pairs covering all four guardrails.
- Greenwashing test: agent must not endorse unverified product claims.
- Source accuracy test: EduAgent citations must reference only IPCC, NASA, or EPA documents.
- Positive framing test: responses must not contain flagged alarmist phrases.
- Latency test: all text-only endpoints must respond within 2 seconds on local hardware.
- The suite integrates with `pytest` and produces a pass/fail report.

**Todo List:**
- [ ] Create `tests/eval/` directory with `__init__.py`
- [ ] Create `tests/eval/guardrail_suite.py` with pytest fixtures and test cases for each of
  the four guardrails
- [ ] Create `tests/eval/prompts.json` with labeled adversarial and normal test prompts
- [ ] Add a `pytest` configuration in `pyproject.toml` or `pytest.ini` including the eval suite
- [ ] Integrate latency assertions using `time.perf_counter` around agent calls
- [ ] Add a CI script (`infra/run_eval.sh`) that runs the guardrail suite and fails on any
  guardrail violation

**Relevant Context:**
- Greenwashing check: scan response text for unverified superlative claims
  (e.g., "100% eco-friendly", "carbon neutral" without citation)
- Alarmist phrase list: maintain a configurable blocklist in `tests/eval/alarmist_phrases.txt`

**Status:** [ ] pending

---

### Sub-Task 3.3 — React Frontend Dashboard

**Intent:**
Build the React user-facing dashboard that provides a chat interface, carbon footprint
tracker visualization, recycling lookup, and community leaderboard — all backed by the
FastAPI `POST /chat` and supporting REST endpoints.

**Expected Outcomes:**
- React app scaffolded with Vite in `frontend/`.
- Chat interface sends messages to `POST /chat` and renders agent responses with citations.
- Carbon dashboard displays footprint history as a chart (e.g., recharts).
- Recycling lookup supports photo upload.
- Leaderboard page shows top-N community members.
- App builds without errors (`npm run build`).

**Todo List:**
- [ ] Scaffold Vite + React project in `frontend/` (`npm create vite@latest`)
- [ ] Create `frontend/src/components/ChatInterface.jsx` wired to `POST /chat`
- [ ] Create `frontend/src/components/FootprintDashboard.jsx` with recharts bar/line chart
- [ ] Create `frontend/src/components/RecycleLookup.jsx` with file upload and image preview
- [ ] Create `frontend/src/components/Leaderboard.jsx` polling `GET /agents/community/leaderboard`
- [ ] Add `frontend/src/api/client.js` as a typed API client for all backend endpoints
- [ ] Ensure `npm run build` succeeds and `npm run dev` proxies to the FastAPI backend

**Relevant Context:**
- API base URL configured via `VITE_API_BASE_URL` environment variable
- No auth UI in scope for this iteration; user identity is a placeholder UUID

**Status:** [ ] pending

---

### Sub-Task 3.4 — Cloud Deployment

**Intent:**
Package and deploy the backend microservices and React frontend to cloud infrastructure so
the application is publicly accessible.

**Expected Outcomes:**
- Backend FastAPI app containerized as a Docker image and deployable via `docker compose up`.
- `infra/Dockerfile.backend` builds a production-ready image.
- `infra/Dockerfile.frontend` builds and serves the React static bundle (nginx).
- `infra/docker-compose.prod.yml` composes all services (API, frontend, postgres, redis)
  for a cloud VM or container platform deployment.
- A `DEPLOYMENT.md` documents the required environment variables and deploy steps.

**Todo List:**
- [ ] Create `infra/Dockerfile.backend` (Python 3.11 slim, install deps, run uvicorn)
- [ ] Create `infra/Dockerfile.frontend` (node build stage + nginx serve stage)
- [ ] Create `infra/docker-compose.prod.yml` with all four services and production env overrides
- [ ] Add `DEPLOYMENT.md` documenting required env vars (`DATABASE_URL`, `REDIS_URL`,
  `SECRET_KEY`, `VITE_API_BASE_URL`) and cloud provider setup steps
- [ ] Run `docker compose -f infra/docker-compose.prod.yml build` locally and confirm
  all images build cleanly
- [ ] Verify health check endpoint `GET /health` returns 200 from the containerized API

**Relevant Context:**
- Cloud target is not pinned — `docker-compose.prod.yml` is portable to any Docker-capable host
  (e.g., AWS EC2, Railway, Fly.io, DigitalOcean Droplet)
- PostgreSQL and Redis in production should use managed services or named volumes with backups;
  this plan uses container-based services as a starting point

**Status:** [ ] pending
