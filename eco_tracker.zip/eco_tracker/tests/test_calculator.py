# tests/test_calculator.py
"""
Unit tests for EmissionCalculator.
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from calculator import EmissionCalculator, CATEGORIES, CONVERSION_FACTORS


@pytest.fixture
def calc() -> EmissionCalculator:
    return EmissionCalculator()


# ---------------------------------------------------------------------------
# calculate()
# ---------------------------------------------------------------------------

class TestCalculate:
    def test_car_emission(self, calc: EmissionCalculator) -> None:
        """100 km by car = 100 * 0.21 = 21.0 kg CO2e."""
        assert calc.calculate("Transportation", "Car", 100.0) == pytest.approx(21.0)

    def test_bus_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Transportation", "Bus", 50.0) == pytest.approx(4.45)

    def test_flight_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Transportation", "Flight", 1000.0) == pytest.approx(255.0)

    def test_bicycle_zero_emission(self, calc: EmissionCalculator) -> None:
        """Bicycle has a factor of 0.0."""
        assert calc.calculate("Transportation", "Bicycle", 20.0) == pytest.approx(0.0)

    def test_electricity_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Energy", "Electricity", 10.0) == pytest.approx(2.33)

    def test_natural_gas_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Energy", "Natural Gas", 10.0) == pytest.approx(2.03)

    def test_beef_meal_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Diet", "Beef Meal", 3.0) == pytest.approx(18.0)

    def test_vegan_meal_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Diet", "Vegan Meal", 2.0) == pytest.approx(0.6)

    def test_landfill_waste_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Waste", "Landfill Waste", 4.0) == pytest.approx(2.0)

    def test_recycled_waste_emission(self, calc: EmissionCalculator) -> None:
        assert calc.calculate("Waste", "Recycled Waste", 4.0) == pytest.approx(0.08)

    def test_fractional_value(self, calc: EmissionCalculator) -> None:
        """Test that fractional km are handled correctly."""
        result = calc.calculate("Transportation", "Car", 0.5)
        assert result == pytest.approx(0.105)

    def test_unknown_category_raises(self, calc: EmissionCalculator) -> None:
        with pytest.raises(ValueError, match="Unknown category"):
            calc.calculate("Shopping", "Online Order", 1.0)

    def test_unknown_activity_type_raises(self, calc: EmissionCalculator) -> None:
        with pytest.raises(ValueError, match="Unknown activity type"):
            calc.calculate("Transportation", "Hoverboard", 10.0)


# ---------------------------------------------------------------------------
# get_activity_types()
# ---------------------------------------------------------------------------

class TestGetActivityTypes:
    def test_returns_list(self, calc: EmissionCalculator) -> None:
        result = calc.get_activity_types("Transportation")
        assert isinstance(result, list)
        assert "Car" in result
        assert "Bus" in result

    def test_energy_types(self, calc: EmissionCalculator) -> None:
        result = calc.get_activity_types("Energy")
        assert "Electricity" in result
        assert "Natural Gas" in result

    def test_unknown_category_raises(self, calc: EmissionCalculator) -> None:
        with pytest.raises(ValueError, match="Unknown category"):
            calc.get_activity_types("Fashion")


# ---------------------------------------------------------------------------
# get_unit()
# ---------------------------------------------------------------------------

class TestGetUnit:
    def test_car_unit_is_km(self, calc: EmissionCalculator) -> None:
        assert calc.get_unit("Transportation", "Car") == "km"

    def test_electricity_unit_is_kwh(self, calc: EmissionCalculator) -> None:
        assert calc.get_unit("Energy", "Electricity") == "kWh"

    def test_beef_unit_is_meal(self, calc: EmissionCalculator) -> None:
        assert calc.get_unit("Diet", "Beef Meal") == "meal"

    def test_waste_unit_is_kg(self, calc: EmissionCalculator) -> None:
        assert calc.get_unit("Waste", "Landfill Waste") == "kg"

    def test_unknown_category_raises(self, calc: EmissionCalculator) -> None:
        with pytest.raises(ValueError):
            calc.get_unit("Unknown", "Something")

    def test_unknown_activity_raises(self, calc: EmissionCalculator) -> None:
        with pytest.raises(ValueError):
            calc.get_unit("Energy", "Nuclear")


# ---------------------------------------------------------------------------
# CATEGORIES constant
# ---------------------------------------------------------------------------

class TestCategories:
    def test_four_categories(self) -> None:
        assert len(CATEGORIES) == 4

    def test_expected_categories_present(self) -> None:
        for cat in ["Transportation", "Energy", "Diet", "Waste"]:
            assert cat in CATEGORIES

    def test_all_categories_in_factors(self) -> None:
        for cat in CATEGORIES:
            assert cat in CONVERSION_FACTORS
