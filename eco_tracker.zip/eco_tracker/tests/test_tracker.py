# tests/test_tracker.py
"""
Unit tests for BudgetTracker and ActivityLog.
Uses a temporary directory to isolate JSON persistence from the real data file.
"""

import datetime
import json
import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from tracker import BudgetTracker, ActivityLog
from data_store import DataStore


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tracker(tmp_path, monkeypatch) -> BudgetTracker:
    """
    Provide a BudgetTracker that reads/writes to a temp directory,
    ensuring tests never touch the real eco_data.json file.
    """
    tmp_data = tmp_path / "data"
    tmp_data.mkdir()
    tmp_file = tmp_data / "eco_data.json"

    monkeypatch.setattr("data_store.DATA_DIR", str(tmp_data))
    monkeypatch.setattr("data_store.FILE_PATH", str(tmp_file))

    return BudgetTracker()


TODAY = datetime.date.today()
YESTERDAY = TODAY - datetime.timedelta(days=1)


# ---------------------------------------------------------------------------
# ActivityLog
# ---------------------------------------------------------------------------

class TestActivityLog:
    def test_to_dict_round_trip(self) -> None:
        log = ActivityLog(
            date=TODAY,
            category="Transportation",
            activity_type="Car",
            value=10.0,
            emission=2.1,
            description="Test drive",
        )
        d = log.to_dict()
        restored = ActivityLog.from_dict(d)

        assert restored.date == log.date
        assert restored.category == log.category
        assert restored.activity_type == log.activity_type
        assert restored.value == log.value
        assert restored.emission == log.emission
        assert restored.description == log.description

    def test_from_dict_default_description(self) -> None:
        d = {
            "date": TODAY.isoformat(),
            "category": "Energy",
            "activity_type": "Electricity",
            "value": 5.0,
            "emission": 1.165,
        }
        log = ActivityLog.from_dict(d)
        assert log.description == ""

    def test_repr_contains_category(self) -> None:
        log = ActivityLog(TODAY, "Diet", "Vegan Meal", 1.0, 0.3)
        assert "Diet" in repr(log)


# ---------------------------------------------------------------------------
# BudgetTracker.set_budget()
# ---------------------------------------------------------------------------

class TestSetBudget:
    def test_valid_budget(self, tracker: BudgetTracker) -> None:
        tracker.set_budget(150.0)
        assert tracker.monthly_budget == 150.0

    def test_integer_budget_accepted(self, tracker: BudgetTracker) -> None:
        tracker.set_budget(200)
        assert tracker.monthly_budget == 200.0

    def test_zero_budget_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(ValueError, match="positive"):
            tracker.set_budget(0.0)

    def test_negative_budget_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(ValueError, match="positive"):
            tracker.set_budget(-50.0)

    def test_string_budget_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(TypeError):
            tracker.set_budget("one hundred")  # type: ignore

    def test_budget_persisted(self, tracker: BudgetTracker, tmp_path) -> None:
        tracker.set_budget(75.0)
        # Reload a fresh tracker from the same temp dir
        t2 = BudgetTracker()
        assert t2.monthly_budget == 75.0


# ---------------------------------------------------------------------------
# BudgetTracker.add_log()
# ---------------------------------------------------------------------------

class TestAddLog:
    def test_valid_log_appended(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Transportation", "Car", 10.0)
        assert len(tracker.logs) == 1

    def test_emission_computed_correctly(self, tracker: BudgetTracker) -> None:
        log = tracker.add_log(TODAY, "Transportation", "Car", 100.0)
        assert log.emission == pytest.approx(21.0)

    def test_description_stored(self, tracker: BudgetTracker) -> None:
        log = tracker.add_log(TODAY, "Diet", "Beef Meal", 1.0, description="Lunch")
        assert log.description == "Lunch"

    def test_zero_value_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(ValueError, match="positive"):
            tracker.add_log(TODAY, "Energy", "Electricity", 0.0)

    def test_negative_value_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(ValueError, match="positive"):
            tracker.add_log(TODAY, "Energy", "Electricity", -5.0)

    def test_non_numeric_value_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(TypeError):
            tracker.add_log(TODAY, "Energy", "Electricity", "ten")  # type: ignore

    def test_future_date_raises(self, tracker: BudgetTracker) -> None:
        future = TODAY + datetime.timedelta(days=1)
        with pytest.raises(ValueError, match="future"):
            tracker.add_log(future, "Energy", "Electricity", 5.0)

    def test_invalid_category_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(ValueError, match="Invalid category"):
            tracker.add_log(TODAY, "Shopping", "T-Shirt", 1.0)

    def test_invalid_activity_type_raises(self, tracker: BudgetTracker) -> None:
        with pytest.raises(ValueError):
            tracker.add_log(TODAY, "Transportation", "Rocket", 100.0)

    def test_past_date_accepted(self, tracker: BudgetTracker) -> None:
        log = tracker.add_log(YESTERDAY, "Waste", "Recycled Waste", 2.0)
        assert log.date == YESTERDAY


# ---------------------------------------------------------------------------
# BudgetTracker.get_total_emissions()
# ---------------------------------------------------------------------------

class TestGetTotalEmissions:
    def test_empty_logs_returns_zero(self, tracker: BudgetTracker) -> None:
        assert tracker.get_total_emissions(TODAY.month, TODAY.year) == 0.0

    def test_single_log(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Transportation", "Car", 100.0)
        total = tracker.get_total_emissions(TODAY.month, TODAY.year)
        assert total == pytest.approx(21.0)

    def test_multiple_logs_summed(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Transportation", "Car", 100.0)   # 21.0
        tracker.add_log(TODAY, "Energy", "Electricity", 10.0)    # 2.33
        total = tracker.get_total_emissions(TODAY.month, TODAY.year)
        assert total == pytest.approx(23.33)

    def test_different_month_excluded(self, tracker: BudgetTracker) -> None:
        """A log from a different month must NOT affect the current month total."""
        other_month = 1 if TODAY.month != 1 else 2
        other_date = datetime.date(TODAY.year - 1, other_month, 1)
        tracker.add_log(other_date, "Diet", "Beef Meal", 1.0)  # 6.0
        tracker.add_log(TODAY, "Transportation", "Car", 10.0)   # 2.1
        total = tracker.get_total_emissions(TODAY.month, TODAY.year)
        assert total == pytest.approx(2.1)


# ---------------------------------------------------------------------------
# BudgetTracker.get_remaining_budget()
# ---------------------------------------------------------------------------

class TestGetRemainingBudget:
    def test_full_budget_when_no_logs(self, tracker: BudgetTracker) -> None:
        tracker.set_budget(100.0)
        assert tracker.get_remaining_budget(TODAY.month, TODAY.year) == pytest.approx(100.0)

    def test_remaining_after_logs(self, tracker: BudgetTracker) -> None:
        tracker.set_budget(100.0)
        tracker.add_log(TODAY, "Transportation", "Car", 100.0)  # 21.0
        assert tracker.get_remaining_budget(TODAY.month, TODAY.year) == pytest.approx(79.0)

    def test_negative_remaining_when_over_budget(self, tracker: BudgetTracker) -> None:
        tracker.set_budget(10.0)
        tracker.add_log(TODAY, "Diet", "Beef Meal", 5.0)  # 30.0
        assert tracker.get_remaining_budget(TODAY.month, TODAY.year) == pytest.approx(-20.0)

    def test_zero_budget_returns_negative_total(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Transportation", "Car", 10.0)  # 2.1
        assert tracker.get_remaining_budget(TODAY.month, TODAY.year) == pytest.approx(-2.1)


# ---------------------------------------------------------------------------
# BudgetTracker.get_category_breakdown()
# ---------------------------------------------------------------------------

class TestGetCategoryBreakdown:
    def test_all_categories_present(self, tracker: BudgetTracker) -> None:
        breakdown = tracker.get_category_breakdown(TODAY.month, TODAY.year)
        assert set(breakdown.keys()) == {"Transportation", "Energy", "Diet", "Waste"}

    def test_zeroes_when_no_logs(self, tracker: BudgetTracker) -> None:
        breakdown = tracker.get_category_breakdown(TODAY.month, TODAY.year)
        assert all(v == 0.0 for v in breakdown.values())

    def test_correct_category_values(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Transportation", "Car", 100.0)  # 21.0
        tracker.add_log(TODAY, "Diet", "Beef Meal", 2.0)        # 12.0
        breakdown = tracker.get_category_breakdown(TODAY.month, TODAY.year)
        assert breakdown["Transportation"] == pytest.approx(21.0)
        assert breakdown["Diet"] == pytest.approx(12.0)
        assert breakdown["Energy"] == 0.0
        assert breakdown["Waste"] == 0.0


# ---------------------------------------------------------------------------
# BudgetTracker.get_top_category()
# ---------------------------------------------------------------------------

class TestGetTopCategory:
    def test_none_when_no_logs(self, tracker: BudgetTracker) -> None:
        assert tracker.get_top_category(TODAY.month, TODAY.year) is None

    def test_single_category_is_top(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Energy", "Electricity", 10.0)
        assert tracker.get_top_category(TODAY.month, TODAY.year) == "Energy"

    def test_highest_emitting_wins(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Transportation", "Car", 10.0)   # 2.1
        tracker.add_log(TODAY, "Diet", "Beef Meal", 5.0)        # 30.0
        tracker.add_log(TODAY, "Energy", "Electricity", 5.0)    # 1.165
        assert tracker.get_top_category(TODAY.month, TODAY.year) == "Diet"


# ---------------------------------------------------------------------------
# BudgetTracker.get_tip()
# ---------------------------------------------------------------------------

class TestGetTip:
    def test_returns_string(self, tracker: BudgetTracker) -> None:
        assert isinstance(tracker.get_tip(TODAY.month, TODAY.year), str)

    def test_tip_when_no_logs_is_default(self, tracker: BudgetTracker) -> None:
        tip = tracker.get_tip(TODAY.month, TODAY.year)
        # Default tip is returned when top_category is None
        assert "Log" in tip or "log" in tip or len(tip) > 10

    def test_tip_matches_top_category(self, tracker: BudgetTracker) -> None:
        tracker.add_log(TODAY, "Diet", "Beef Meal", 10.0)
        tip = tracker.get_tip(TODAY.month, TODAY.year)
        assert "beef" in tip.lower() or "diet" in tip.lower() or "meat" in tip.lower()
