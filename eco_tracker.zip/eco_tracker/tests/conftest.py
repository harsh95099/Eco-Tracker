# conftest.py
# Ensures the eco_tracker package root is importable during pytest runs.
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
