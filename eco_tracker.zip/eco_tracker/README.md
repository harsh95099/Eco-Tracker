# EcoAssistant

A multi-agent AI sustainability platform powered by IBM Bob.

## What It Does

EcoAssistant routes user queries through an **Orchestrator Agent** that classifies intent and
delegates to one of four specialized sub-agents:

| Agent | Purpose | Tool |
|---|---|---|
| **EduAgent** | Climate facts, policy, science (RAG over IPCC/EPA/NASA) | `search_climate_db` |
| **TrackerAgent** | CO2e carbon footprint calculator | `calculate_footprint` |
| **RecycleAgent** | Waste classification and disposal guidance | `classify_waste_item` |
| **CommunityAgent** | Local events, leaderboards, impact tracking | `get_local_events` |

## Project Structure

```
.
├── agents/
│   ├── orchestrator/       # Orchestrator Agent — intent routing
│   ├── edu_agent/          # RAG pipeline — ChromaDB + sentence-transformers
│   ├── tracker_agent/      # Carbon calculator — EPA emission factors
│   ├── recycle_agent/      # Vision + text waste classifier — CLIP
│   └── community_agent/    # Events + Redis leaderboard
├── backend/
│   ├── main.py             # FastAPI entry point
│   ├── router/             # Orchestrator dispatcher
│   └── db/                 # SQLAlchemy models, session, migrations
├── frontend/               # React + Vite dashboard
├── infra/                  # Docker Compose, Dockerfiles
├── data/
│   └── sources/            # IPCC, EPA, NASA source documents for ingestion
├── tests/
│   └── eval/               # Guardrail evaluation suite (pytest)
├── .bob/
│   └── custom_modes.yaml   # EcoAssistant IBM Bob custom mode
└── ecoassistant-plan.md    # Full phased execution roadmap
```

## Stack

- **Backend:** Python 3.11, FastAPI, Uvicorn
- **Databases:** PostgreSQL 15 (persistent data), Redis 7 (leaderboard cache)
- **Vector DB:** ChromaDB (local-first RAG)
- **Embeddings:** `sentence-transformers/all-MiniLM-L6-v2`
- **Vision Model:** `openai/clip-vit-base-patch32` (zero-shot waste classification)
- **Frontend:** React + Vite, Recharts
- **Infra:** Docker Compose (dev + prod)

## Quick Start (Local Development)

### Prerequisites
- Docker Desktop
- Python 3.11+
- Node.js 18+

### 1. Start infrastructure services
```bash
docker compose -f infra/docker-compose.yml up -d
```

### 2. Install backend dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 3. Run the API
```bash
uvicorn backend.main:app --reload
```

### 4. Run the frontend
```bash
cd frontend
npm install
npm run dev
```

API will be available at `http://localhost:8000`
Frontend will be available at `http://localhost:5173`

## Environment Variables

Copy `.env.example` to `.env` and fill in:

| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `SECRET_KEY` | App secret key |
| `VITE_API_BASE_URL` | Backend URL for the frontend |

## IBM Bob Custom Mode

The `EcoAssistant` mode is registered in [`.bob/custom_modes.yaml`](.bob/custom_modes.yaml).
It appears in the IBM Bob mode picker automatically (workspace-scoped, hot-reloaded).

## Implementation Plan

See [`ecoassistant-plan.md`](ecoassistant-plan.md) for the full phased execution roadmap
with 10 sub-tasks across 3 phases.

## Guardrails

All agent responses are validated against four guardrails (see Sub-Task 3.2):
1. **Zero greenwashing** — no unverified eco-friendly claims
2. **Source accuracy** — EduAgent citations must be IPCC, NASA, or EPA only
3. **Positive framing** — no alarmist language
4. **Latency** — text-only responses under 2 seconds
