"""
data_store.py
Handles saving and loading application state to/from a local JSON file.
No Streamlit imports allowed in this module.
"""

import json
import os
from typing import List, Tuple


DATA_DIR: str = os.path.join(os.path.dirname(__file__), "data")
FILE_PATH: str = os.path.join(DATA_DIR, "eco_data.json")


class DataStore:
    """Persists and retrieves logs and budget from a local JSON file."""

    def save(self, logs: List[dict], budget: float) -> None:
        """
        Write current state to eco_data.json.

        Args:
            logs: List of serialised ActivityLog dicts.
            budget: Current monthly budget as a float.
        """
        os.makedirs(DATA_DIR, exist_ok=True)
        payload = {"monthly_budget": budget, "logs": logs}
        with open(FILE_PATH, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, default=str)

    def load(self) -> Tuple[List[dict], float]:
        """
        Load state from eco_data.json.

        Returns:
            A tuple of (list_of_log_dicts, monthly_budget).
            Returns ([], 0.0) if the file does not exist or is corrupted.
        """
        if not os.path.exists(FILE_PATH):
            return [], 0.0
        try:
            with open(FILE_PATH, "r", encoding="utf-8") as f:
                payload = json.load(f)
            logs: List[dict] = payload.get("logs", [])
            budget: float = float(payload.get("monthly_budget", 0.0))
            return logs, budget
        except (json.JSONDecodeError, ValueError, KeyError):
            # Corrupted file — start fresh
            return [], 0.0
