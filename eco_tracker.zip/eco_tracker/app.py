"""
app.py
Streamlit UI for the Personal Eco-Impact & Sustainability Tracker.
This module only handles presentation; all logic is delegated to BudgetTracker.
"""

import datetime
import sys
import os

# Ensure the eco_tracker package directory is on the path when running via
# `streamlit run eco_tracker/app.py` from the project root.
sys.path.insert(0, os.path.dirname(__file__))

import streamlit as st
from tracker import BudgetTracker
from calculator import CATEGORIES

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Eco-Impact Tracker",
    page_icon="🌱",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Session-state initialisation
# Instantiate BudgetTracker once per session so data persists across reruns.
# ---------------------------------------------------------------------------
if "tracker" not in st.session_state:
    st.session_state.tracker = BudgetTracker()

tracker: BudgetTracker = st.session_state.tracker

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def show_error(msg: str) -> None:
    st.error(f"⚠️ {msg}")


def show_success(msg: str) -> None:
    st.success(f"✅ {msg}")


# ---------------------------------------------------------------------------
# Sidebar — month selector & budget setting
# ---------------------------------------------------------------------------
with st.sidebar:
    st.title("🌱 Eco Tracker")
    st.markdown("---")

    # Month / year selector
    st.subheader("📅 Viewing Month")
    today = datetime.date.today()
    selected_year: int = st.number_input(
        "Year", min_value=2020, max_value=today.year, value=today.year, step=1
    )
    selected_month: int = st.selectbox(
        "Month",
        options=list(range(1, 13)),
        index=today.month - 1,
        format_func=lambda m: datetime.date(2000, m, 1).strftime("%B"),
    )

    st.markdown("---")

    # Budget setting
    st.subheader("🎯 Monthly Budget")
    budget_input = st.number_input(
        "Target CO₂e budget (kg)",
        min_value=0.0,
        value=float(tracker.monthly_budget) if tracker.monthly_budget > 0 else 100.0,
        step=10.0,
        format="%.1f",
    )
    if st.button("Set Budget", use_container_width=True):
        try:
            tracker.set_budget(budget_input)
            show_success(f"Budget set to **{budget_input:.1f} kg CO₂e / month**.")
        except (ValueError, TypeError) as exc:
            show_error(str(exc))

    if tracker.monthly_budget > 0:
        st.info(f"Current budget: **{tracker.monthly_budget:.1f} kg CO₂e**")
    else:
        st.warning("No budget set yet.")

# ---------------------------------------------------------------------------
# Main area — tabs
# ---------------------------------------------------------------------------
tab_log, tab_dashboard, tab_history = st.tabs(
    ["➕ Log Activity", "📊 Dashboard", "📋 History"]
)

# ===========================================================================
# TAB 1 — Log a new activity
# ===========================================================================
with tab_log:
    st.header("Log a New Activity")

    col1, col2 = st.columns(2)

    with col1:
        log_date: datetime.date = st.date_input(
            "Date",
            value=today,
            max_value=today,
        )
        category: str = st.selectbox("Category", options=CATEGORIES)

    activity_types = tracker.get_activity_types(category)

    with col2:
        activity_type: str = st.selectbox("Activity Type", options=activity_types)
        unit = tracker.get_unit(category, activity_type)
        activity_value: float = st.number_input(
            f"Amount ({unit})",
            min_value=0.0,
            step=1.0,
            format="%.2f",
        )

    description: str = st.text_input(
        "Description (optional)",
        placeholder="e.g. Morning commute to work",
    )

    if st.button("➕ Add Activity", use_container_width=True, type="primary"):
        try:
            log = tracker.add_log(
                date=log_date,
                category=category,
                activity_type=activity_type,
                value=activity_value,
                description=description,
            )
            show_success(
                f"Logged **{log.value} {unit}** of **{log.activity_type}** "
                f"→ **{log.emission:.3f} kg CO₂e**"
            )
        except (ValueError, TypeError) as exc:
            show_error(str(exc))

# ===========================================================================
# TAB 2 — Dashboard
# ===========================================================================
with tab_dashboard:
    month_label = datetime.date(selected_year, selected_month, 1).strftime("%B %Y")
    st.header(f"Dashboard — {month_label}")

    total: float = tracker.get_total_emissions(selected_month, selected_year)
    remaining: float = tracker.get_remaining_budget(selected_month, selected_year)
    breakdown: dict = tracker.get_category_breakdown(selected_month, selected_year)
    tip: str = tracker.get_tip(selected_month, selected_year)

    # --- KPI metrics ---
    col_a, col_b, col_c = st.columns(3)

    with col_a:
        st.metric(
            label="Total Emissions",
            value=f"{total:.2f} kg CO₂e",
        )

    with col_b:
        if tracker.monthly_budget > 0:
            delta_color = "normal" if remaining >= 0 else "inverse"
            st.metric(
                label="Remaining Budget",
                value=f"{remaining:.2f} kg CO₂e",
                delta=f"{remaining:.2f} remaining",
                delta_color=delta_color,
            )
        else:
            st.metric(label="Remaining Budget", value="—", help="Set a budget first.")

    with col_c:
        if tracker.monthly_budget > 0:
            pct = min((total / tracker.monthly_budget) * 100, 100)
            st.metric(
                label="Budget Used",
                value=f"{pct:.1f}%",
            )
        else:
            st.metric(label="Budget Used", value="—")

    # Over-budget warning
    if tracker.monthly_budget > 0 and remaining < 0:
        st.error(
            f"🚨 You are **{abs(remaining):.2f} kg CO₂e over budget** for {month_label}!"
        )

    st.markdown("---")

    # --- Category breakdown bar chart ---
    st.subheader("📊 Category Breakdown")
    if total == 0.0:
        st.info("No activities logged for this month yet. Log your first activity!")
    else:
        chart_data = {
            "Category": list(breakdown.keys()),
            "kg CO₂e": list(breakdown.values()),
        }
        import pandas as pd
        df = pd.DataFrame(chart_data).set_index("Category")
        st.bar_chart(df, color="#2ecc71")

        # Percentage labels
        cols = st.columns(len(CATEGORIES))
        for i, cat in enumerate(CATEGORIES):
            val = breakdown[cat]
            pct_cat = (val / total * 100) if total > 0 else 0.0
            cols[i].metric(label=cat, value=f"{val:.2f} kg", delta=f"{pct_cat:.1f}%")

    st.markdown("---")

    # --- Tip ---
    st.subheader("💡 Personalised Tip")
    st.info(tip)

# ===========================================================================
# TAB 3 — History table
# ===========================================================================
with tab_history:
    st.header("Activity History")

    if not tracker.logs:
        st.info("No activities logged yet.")
    else:
        import pandas as pd

        rows = [
            {
                "Date": log.date.isoformat(),
                "Category": log.category,
                "Activity": log.activity_type,
                "Value": log.value,
                "Unit": tracker.get_unit(log.category, log.activity_type),
                "CO₂e (kg)": log.emission,
                "Description": log.description,
            }
            for log in sorted(tracker.logs, key=lambda l: l.date, reverse=True)
        ]

        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True, hide_index=True)

        # Filter to selected month
        month_logs = [
            log for log in tracker.logs
            if log.date.month == selected_month and log.date.year == selected_year
        ]
        st.caption(
            f"Showing all {len(tracker.logs)} entries. "
            f"{len(month_logs)} entries in "
            f"{datetime.date(selected_year, selected_month, 1).strftime('%B %Y')}."
        )
