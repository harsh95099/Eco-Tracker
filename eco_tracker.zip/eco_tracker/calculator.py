"""
calculator.py
Emission calculation engine.
Contains fixed conversion factors and pure calculation logic.
No Streamlit imports allowed in this module.
"""

from typing import Dict, List


# Conversion factors: kg CO2e per unit
# Structure: { category: { activity_type: (factor, unit_label) } }
CONVERSION_FACTORS: Dict[str, Dict[str, tuple]] = {
    "Transportation": {
        "Car":      (0.21,  "km"),
        "Bus":      (0.089, "km"),
        "Flight":   (0.255, "km"),
        "Train":    (0.041, "km"),
        "Bicycle":  (0.0,   "km"),
    },
    "Energy": {
        "Electricity": (0.233, "kWh"),
        "Natural Gas":  (0.203, "kWh"),
    },
    "Diet": {
        "Beef Meal":       (6.0, "meal"),
        "Chicken Meal":    (1.5, "meal"),
        "Vegetarian Meal": (0.5, "meal"),
        "Vegan Meal":      (0.3, "meal"),
    },
    "Waste": {
        "Landfill Waste": (0.5,  "kg"),
        "Recycled Waste": (0.02, "kg"),
    },
}

CATEGORIES: List[str] = list(CONVERSION_FACTORS.keys())


class EmissionCalculator:
    """Computes CO2e emissions from activity type and quantity."""

    def calculate(self, category: str, activity_type: str, value: float) -> float:
        """
        Calculate CO2e emission for an activity.

        Args:
            category: One of the allowed category strings.
            activity_type: Specific activity within the category.
            value: Numeric quantity (km, kWh, meals, kg).

        Returns:
            Emission in kg CO2e (float).

        Raises:
            ValueError: If category or activity_type is unknown.
        """
        if category not in CONVERSION_FACTORS:
            raise ValueError(f"Unknown category: '{category}'.")
        if activity_type not in CONVERSION_FACTORS[category]:
            raise ValueError(
                f"Unknown activity type: '{activity_type}' for category '{category}'."
            )
        factor, _ = CONVERSION_FACTORS[category][activity_type]
        return round(value * factor, 4)

    def get_activity_types(self, category: str) -> List[str]:
        """Return list of valid activity type names for a given category."""
        if category not in CONVERSION_FACTORS:
            raise ValueError(f"Unknown category: '{category}'.")
        return list(CONVERSION_FACTORS[category].keys())

    def get_unit(self, category: str, activity_type: str) -> str:
        """Return the unit label (e.g. 'km', 'kWh') for an activity type."""
        if category not in CONVERSION_FACTORS:
            raise ValueError(f"Unknown category: '{category}'.")
        if activity_type not in CONVERSION_FACTORS[category]:
            raise ValueError(
                f"Unknown activity type: '{activity_type}' for category '{category}'."
            )
        _, unit = CONVERSION_FACTORS[category][activity_type]
        return unit
