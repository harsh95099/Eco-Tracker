"""
tips.py
Provides one targeted reduction tip per emission category.
No Streamlit imports allowed in this module.
"""

from typing import Optional

TIPS: dict = {
    "Transportation": (
        "Try switching to public transport, carpooling, or cycling for short trips. "
        "Even one car-free day per week makes a measurable difference."
    ),
    "Energy": (
        "Turn off standby devices, switch to LED lighting, and lower your thermostat "
        "by 1–2°C to cut energy emissions significantly."
    ),
    "Diet": (
        "Reducing beef and dairy meals — even just once a week — is one of the highest-impact "
        "dietary changes you can make for the climate."
    ),
    "Waste": (
        "Separate recyclables from landfill waste and compost organic matter to dramatically "
        "reduce the emissions from your rubbish."
    ),
}

DEFAULT_TIP: str = (
    "Log your activities to get a personalised tip based on your highest-impact category."
)


class TipsEngine:
    """Looks up a reduction tip for a given emission category."""

    def get_tip(self, category: Optional[str]) -> str:
        """
        Return a reduction tip for the given category.

        Args:
            category: One of the allowed category strings, or None.

        Returns:
            A tip string. Returns DEFAULT_TIP if category is None or unrecognised.
        """
        if category is None:
            return DEFAULT_TIP
        return TIPS.get(category, DEFAULT_TIP)
